/* HATEGAN FLorin George - 311 CB*/
#include "head.h"


int cmp (int fcv,char* key,void* a)
{
	TE x = (TE)a;
	if (fcv != x->frecv)
	{
	return (fcv - x->frecv);
	}
	else
	if (strcmp ( key , x->key ) < 0 )
	return 1;
	return -1;
}


int nrelem ( ALC a )
{
	int s = 0;
	TLC p = *a;
	if( p == NULL)
		return 0;
	else
		p = p->urm;
	s++;
	while (p!= *a)
		{
		s++;
		p = p->urm;
		}
	return s;
}

void elib(void* a)
{
	TE x;
	x = (TE)a;
	free( x->key );
	free( x->value );
}


void elimina(ALC y)
{
	TLC aux;
	aux = *y;
	if( *y != aux->urm){
		aux->urm->ant = aux->ant;
		aux->ant->urm = aux->urm;
		*y = (*y)->urm; 
	}
	else
		*y = NULL;
	elib( aux->info );
	free( aux->info );
	free( aux );

}

TElement* alocare(char* key,char* value,int fcv)
{
	TElement* aux;
	aux = (TElement*)malloc(sizeof(TElement));
	if (!aux)
		return NULL;
	aux->key = strdup(key);
	aux->value = strdup(value);
	aux->frecv = fcv;
	return aux;
}

int AlocCel(char* key, char* value,int fcv,ALC x)
{
  TLC p, aux = malloc(sizeof(TCelula));
  if( !aux ) return 0;
  aux->info = malloc(sizeof(TElement));
  if (!aux->info)
  { free( aux ); return 0;}
  memcpy(aux->info, alocare(key,value,fcv) , sizeof( TElement ));
  if ( nrelem(x) != 0)
  	{
 	 p = *x;
 	 if ( cmp(fcv, key, p->info) < 0)
  	{
  		p = p->urm;
 		while(p != *x)
 		{
  		if (cmp(fcv, key, p->info) > 0)
  			break;
  		p = p->urm;
  		}
 	}
  	aux->urm = p;
  	aux->ant = p->ant;
  	p->ant->urm = aux;
  	p->ant = aux;
  	if ( cmp(fcv, key, p->info) > 0 && p == *x )
  		 *x = aux;
  	}
  	else
  	{
  	aux->ant = aux;
  	aux->urm = aux;
  	*x = aux;
  	}
  return 0;
}


void afisare(void* a,FILE* f)
{
	TE x;
	x=(TE)a;
	fprintf(f, " (%s)", x->value);
}



int verif1(char *key,TLC a)
{
	if ( a!= NULL ) {
		TLC b = a->urm;
		TE x = (TE)a->info;
		if ( strcmp(x->key ,key) == 0)
			return 1;
		for (; b != a;b = b->urm ){
			TE x = (TE)b->info;
			if ( strcmp(x->key ,key) == 0)
				return 1;
		}
	}
	return 0;
}

void printlist(TLC a,FILE *f)
{
	TLC y = a;
	if ( a != NULL){
		afisare( y->info, f );
		y = y->urm;
	while ( y != a )
		{
		afisare( y->info, f );
		y = y->urm;
		}
	fprintf(f,"\n");
	}
}



TH* InitTH(int M,FHash f)
{
	TH *a = (TH*)calloc(sizeof(TH), 1);
	if ( !a ) 
		return NULL;
	a->v = (TLC*)calloc(M, sizeof(TLC));
	if( !a->v )
	{
		free( a );
		return NULL;
	}
	int i = 0;
	for (; i < M; i++)
  		a->v[i] = NULL;
	a->M = M;
	a->fh = f;
	return a;
}

void DistrTH(TH* a)
{	
	TLC x;
	int i = 0;
	for( ; i < a->M ; i++)
		{
		x = a->v[i];
		int j = 1, nr = nrelem(&x);
		for( ; j <= nr; j++)
			elimina( &x );
		}
	free( a );
	a = NULL;
}


int hash_function(char *key)
{
  int i = 0, sum = 0;
  int l = strlen( key );
  for (; i < l; i++) {
  	sum += key[i];
  }
  return sum;
}

void print_list(TH* a,int x,FILE *f)
{
	if ( x < a->M && x >= 0 )
	{
	fprintf(f, "%d:", x);
	TLC y =  a->v[x];
	TLC z = y;
	if (y != NULL){
		afisare(y->info, f);
		y = y->urm;
		while (y != z)
			{
			afisare( y->info, f );
			y = y->urm;
			}  
		       fprintf(f,"\n");
		}
	else
		fprintf(f," VIDA\n");
		       
	}
}

void print(TH*a,FILE *f)
{
	int i = 0;
	for (; i < a->M ; i++)
	{
		if (a->v[i] != NULL)
			fprintf(f,"%d:",i);
		printlist(a->v[i],f);
	}	
}


void remove1(char* key,TH* a,int* nr)
{
	int buck = a->fh(key) % (a->M);
	TLC x =  a->v[buck] ;
	if (verif1(key,x) != 0) 
		{
			TE aux = (TE)(x->info);
			while( strcmp(key,aux->key) != 0)
				{
				x = x->urm;
				aux = (TE)(x->info);
				}
			*nr -= 1;
			//if urile previn pierderea listei
			if (x == a->v[buck])
				a->v[buck] = x->urm;
			if( nrelem ( &( a->v[buck] ) ) == 1)
				a->v[buck] = NULL;
			elimina( &x );
		}
}

char* get(char* key,TH* a)
{
	int p = 0,buck = a->fh(key) % (a->M);
	TLC x = a->v[buck];
		if ( verif1(key ,x) != 0 ) 
		{
		TE muta = (TE)(x->info);
		while( strcmp(key, muta->key) != 0)
			{
			x = x->urm;
			muta = (TE)(x->info);
		 	}
		muta = (TE)(x->info);
		char *key1, *value1;
		int fcv1;
		fcv1 = muta->frecv + 1;
		key1 = strdup( key );
		value1 = strdup( muta->value );
		// stege elementul si apoi il insereaza ordonat
		remove1 ( key, a, &p );
		AlocCel (key1 ,value1 ,fcv1 ,&( a->v[buck] ) );
		return value1;
		}
		return "ERROR";
}


void set(char* key,char* value,TH* a,int* nr)
{
int buck = a->fh(key) % (a->M);
TLC x = a->v[buck];
	if ( verif1 (key, x) == 0 )
	{
		if( nrelem(&x) < a->M )
		{
			if ( (*nr + 1) > (2 * a->M) )
			{
			TH *b = InitTH(2 * a->M, a->fh);
			int i = 0;
				for (; i<a->M ; i++)
				{
				TLC y = a->v[i];
				int j = 1;
					for (; j <= nrelem( &y ); j++)
					{
// functia de inserare implementat necesita valorile deci am facut cast
					char *key1, *value1;
  					int fcv1;
 					TE r = (TE)y->info;
 					key1 = r->key;
 					value1 = r->value;
 					fcv1 = r->frecv;
 					int buck1 = b->fh(key1) % (b->M);
 					AlocCel(key1, value1, fcv1, &(b->v[buck1]));
					y = y->urm;
					} 
				}
				int buck2 = b->fh(key) % (b->M);
				AlocCel(key, value, 0, &( b->v[buck2] ) );
			*nr += 1;
			*a = *b;
			}
			else
			{
			AlocCel(key, value, 0, &( a->v[buck] ) );
			*nr += 1;
			}
		}
		else 
		{
		x = x->ant;
		elimina( &x );
		AlocCel(key, value, 0, &( a->v[buck] ) );
		}
	}
}


int main( int argc ,char *argv[] )
{
TH *a = InitTH( atoi(argv[1]) , hash_function);
int nr = 0;
FILE *fp;
FILE *f;
f  = fopen( argv[3] ,"w" );
fp = fopen( argv[2] ,"r" );
char buffer[300], *str;
	//am vrut initial sa implementez cu switch dar se pare ca merge pe inturi...
	while( fgets(buffer , 300, fp) )
	{
	str = strtok ( buffer, " \n");
		if ( strcmp ("set" ,str) == 0) {
			char *x, *y;
			y = strtok(NULL," \n");
			x = strtok(NULL," \n");
			set(y, x, a, &nr);
			}
		if ( strcmp ("get" ,str) == 0) {
			char *x, *y;
			x = strtok(NULL," \n");
			y = get(x, a);
			if ( strcmp (y, "ERROR") != 0 )
				fprintf(f, "%s\n", y);
			else
				fprintf(f, "NULL\n");
			}
		if( strcmp ("print", str) == 0 ){
			print(a, f);
			}
		if( strcmp ("print_list",str) == 0 ){
			char *x;
			x = strtok(NULL," \n");
			print_list(a, atoi(x), f);
			}
		if ( strcmp("remove" ,str) == 0 ){	
			char *x;
			x = strtok(NULL," \n");
			remove1(x, a, &nr);
			}
	}
fclose( fp );
fclose( f );
DistrTH( a );
return 0;

}



